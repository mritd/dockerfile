import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

SECRET_KEY = 'n&ckat81u1q6zr&t1+68vz4(k7_8-t_%q4kj5r^w6izotolsag'

DEBUG = False

ALLOWED_HOSTS = [
    '0.0.0.0',
    '127.0.0.1',
    'localhost'
]

INSTALLED_APPS = []

MIDDLEWARE_CLASSES = []

ROOT_URLCONF = 'jetbrains_license_server.urls'

TEMPLATES = []

WSGI_APPLICATION = 'jetbrains_license_server.wsgi.application'

DATABASES = {}

AUTH_PASSWORD_VALIDATORS = []

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_L10N = True
USE_TZ = True
STATIC_URL = '/static/'

from django.conf.urls import url

from JetBrainsLicenseServer.views import ObtainTicket, Ping

handler404 = 'JetBrainsLicenseServer.views.error404'
handler500 = 'JetBrainsLicenseServer.views.error500'

urlpatterns = [
    url(r'^rpc/obtainTicket\.action/?$', ObtainTicket.as_view()),
    url(r'^rpc/ping\.action/?$', Ping.as_view()),
]
